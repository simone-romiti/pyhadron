# pyhadron

This repository contains a python wrapper for the `hadron` library (written in the `R` language): https://github.com/HISKP-LQCD/hadron.

**Documentation**: See the `doc/` folder for the documentation.
**Installation**: see [install.md](./install.md)
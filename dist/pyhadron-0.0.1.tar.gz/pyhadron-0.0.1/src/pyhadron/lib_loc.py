
# paths of all libraries

# base = "/usr/lib/R/library"
# graphics = "/usr/lib/R/library"
# compositions = "/home/simone/R/x86_64-pc-linux-gnu-library/4.1/"

hadron = "/home/simone/Documents/software-stack/install/hadron/master/"